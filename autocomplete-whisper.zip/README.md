# autocomplete-whisper
Foundry VTT module to enhance chat whisper targeting with typeahead suggestions
